#repeating
str='Core Python'
#n=len(str)
print(str*2)

#concatenating
str2=' Programming'
str3=str+str2
print(str3)

#comparing
if(str==str2):
    print("Same")
else:
    print("Not same")

#removing space
name=' Souvik Majumdar  '
print(name.lstrip())
print(name.rstrip())
print(name.strip())

#replacing string
strng='This is a beautiful place'
s1='place'
s2='flower'
str4=strng.replace(s1,s2)
print(str4)

#immutable
str5='abcd'
print(str5)
str5[0]='s'
