from numpy import *
arr=array([10,20,30,40])
print(arr)

a=array([1,2,3,4,5])
b=array(a)
c=a

print('a=',a)
print('b=',b)
print('c=',c)
