str=['apple','guava','grapes','mango']
sep=':'
str1=sep.join(str)
print(str1)
