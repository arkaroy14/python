c=0
n=int(input("Enter any number: "))
for i in range(2,n,1):
	if(n%i==0):
		c=1
if(c==0):
	print("The number is PRIME")
else:
	print("The number is not PRIME")	

