a=int(input("Enter the number: "))
if a%2==0:
    print("The number is EVEN\n")
else:
    print("The number is ODD\n")
