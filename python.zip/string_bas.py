str='Core Python'
n=len(str)
print(n)

#access each character in loop
i=0
n=len(str)
while i<n:
    print(str[i],end=' ')
    i+=1

print()
#access in reverse order
i=-1
n=len(str)
while i>=-n:
    print(str[i],end=' ')
    i-=1

print()

#access in reverse order using negative index
i=1
n=len(str)
while i<=n:
    print(str[-i],end=' ')
    i+=1
print()

for i in str[:: -1]:
    print(i,end=' ')

