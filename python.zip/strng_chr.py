str=input('Enter a string: ')

i=0

for s in str:
    print(str[i],end='')
    i+=1
print('\nNo of characters: ',i)
