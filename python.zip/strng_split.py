str='one,two,three,four'
str1=str.split(',')
print(str1)


str=input('Enter number by space: ')
lst=str.split(' ')
for i in lst:
    print(i)
