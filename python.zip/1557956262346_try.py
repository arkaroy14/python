n=int(input("Enter the number: "))
a=int(0)
b=int(1)
c=(1)
d=int(0)
print(a)
print(b)
print(c)
for i in range(3,n):
	d=a+b+c
	a=b
	b=c
	c=d
	print(d)
