from array import *
a=array('i',[7,6,-9,3])
print(a.buffer_info())
print(a.typecode)
print(id(a))
