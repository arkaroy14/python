from array import *
vals=array('i',[56,78,96,3])

print(vals.buffer_info())
print(vals.typecode)
