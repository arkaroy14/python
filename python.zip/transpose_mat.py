import sys
from numpy import*

r,c=[int(a) for a in input("First matrix rows,columns: ").split()]

str=input("Enter the matrix elements:\n ")

x=reshape(matrix(str),(r,c))

print('The original matrix:')
print(x)

print('The transpose matrix:')
z=x.transpose()
print(z)
