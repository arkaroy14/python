n=int(input("Enter no of lines: "))
for i in range(n+1,0,-1):
    for j in range(0,i,1):
        print(" ",end=' ')
    for j in range(n+1,i,-1):
        print(" * ",end=' ')
    print()
