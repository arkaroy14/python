for i in range(1,11):
    for j in range(1,11):
        print('{:8}'.format(i*j),end=' ')
    print()

	
