from array import*

arr=array('i',[10,20,30,40,50])
print('Original Array : ',arr)

arr.append(45)
arr.append(65)
print('After appending two values : ',arr)

arr.insert(1,100)
print('After insering 100 in 1st position : ',arr)

arr.remove(20)
print('After removing 20 from array : ',arr)

n=arr.pop()
print('Array After pop : ',arr)
print('Popped element: ',n)

p=arr.index(30)
print('Position of 30 elemnt : ',p)

lst=arr.tolist()
print('List :',lst)
print('Array :',arr)
