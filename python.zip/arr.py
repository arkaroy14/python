from array import *
#integer array
a=array('i',[7,6,-9,3])
print(" The array elements are : ")
for elements in a:
    print(elements)

#character array
b=array('u',['a','b','c','d'])
print("The array is")
for ch in b:
    print(ch)
