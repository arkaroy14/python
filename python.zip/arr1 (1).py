from array import *

#integer array
a=array('i',[7,6,-9,3])

print('The Array Elements are:')
for element in a:
    print(element)

#character array
b=array('u',['a','b','c','d'])

print('The Array Elements are:')
for ch in b:
    print(ch)

#copy array
arr1=array('d',[1.5,2.5,-3.5,4])
arr2=array(arr1.typecode,(a*3 for a in arr1))
print('the array elements are :')
for i in arr2:
    print(i)

#retrieve array element
x=array('i',[10,20,30,40,50])
n=len(x)
print('Elements are')
for i in range(n):
    print(x[i],end=' ')

#array slicing
x=array('i',[10,20,30,40,50])
print('Elements are')
for i in x[2:5]:
    print(i)


