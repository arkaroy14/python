c=0
a=0
n=int(input("Enter "))
if(n<10):
	print("Armstrong")
else:
	m=n
	while (m!=0):
		c=c+1
		m=m//10
	n1=n
	while (n1!=0):
		d=n1%10
		a=a+d**c
		n1=n1//10
	if(a==n):
		print("Armstrong")
	else: 	
		print("Not Armstrong")
