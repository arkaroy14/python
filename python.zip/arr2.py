from array import *
a=array('i',[10,20,30,40,50])
print("Original Array : ",a)

a.append(45)
a.append(65)
print("After appending two values : ",a)

a.insert(1,100)
print("After inserting 100in 1st position : ",a)

a.remove(20)
print("After removing 20 from array : ",a)

n=a.pop()
print("Array after pop : ",a)
print("Popped element : ",n)

p=a.index(30)
print('Position of 30 element : ',p)
